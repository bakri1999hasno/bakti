#!/bin/bash
echo " please enter the firt number: "
  read  a
echo " pelase enter the second number: "
  read  b
echo " a+b value is $(($a+$b))"
echo " a-b value is $(($a-$b))"
echo " a*b value is $(($a*$b))"
echo " a/b value is $(($a/$b))"

