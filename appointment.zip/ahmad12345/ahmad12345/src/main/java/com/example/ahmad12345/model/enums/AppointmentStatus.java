package com.example.ahmad12345.model.enums;

public enum AppointmentStatus {
    PENDING,
    APPROVED,
    CANCELLED,
    COMPLETED,
    REJECTED
}