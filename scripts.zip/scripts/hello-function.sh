#!/bin/bash

say_hello ()

{
  echo "Hello $1, welcome to Bash functions!"
}

say_hello "Mohammad"
say_hello "OS1"
say_hello "Students"

