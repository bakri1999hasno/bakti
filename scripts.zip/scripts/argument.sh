#!/bin/bash
echo "Name of script: $0"
echo "First argument: $1, Second argument: $2"
echo "Number of arguments: $#"
echo "-------------------------"
echo "-- Iterating over \$@ --"
i=1
for arg in $@; do
    echo "Argument $i: $arg"
    ((i++))
done
echo "-------------------------"
echo "-- Iterating over \"\$@\" --"
i=1
for arg in "$@"; do
    echo "Argument $i: $arg"
    ((i++))
done
echo "-------------------------"
echo "-- Iterating over \$* --"
i=1
for arg in $*; do
    echo "Argument $i: $arg"
    ((i++))
done
echo "-------------------------"
echo "-- Iterating over \"\$*\" --"
i=1
for arg in "$*"; do
    echo "Argument $i: $arg"
    ((i++))
done
echo "-------------------------"
echo "Exit status of last command: $?"
sleep 30 &
echo "PID of last background job: $!"
echo "Script completed"

