#!/bin/bash
# Prompt the user for two integers and an operation
read -p "Enter first integer (a): " a
read -p "Enter second integer (b): " b
read -p "Choose operation (+, -, *, /, %): " op

# Validate that inputs are integers (simple check)
if [[ "$a" =~ ^-?[0-9]+$ && "$b" =~ ^-?[0-9]+$ ]]; then
    :
else
    echo "Error: a and b must be integers."
    exit 1
fi
# Perform the arithmetic operation based on the chosen operator
if [[ "$op" == "+" ]]; then
    result=$(( a + b ))
    echo "Result (a + b) = $result"
elif [[ "$op" == "-" ]]; then
    result=$(( a - b ))
    echo "Result (a - b) = $result"
elif [[ "$op" == "*" ]]; then
    result=$(( a * b ))
    echo "Result (a * b) = $result"
elif [[ "$op" == "/" ]]; then
    if [[ "$b" -eq 0 ]]; then
        echo "Error: Division by zero is not allowed."
        exit 2
    fi
    # Integer division
    result=$(( a / b ))
    echo "Result (a / b) = $result"
elif [[ "$op" == "%" ]]; then
    if [[ "$b" -eq 0 ]]; then
        echo "Error: Modulo by zero is not allowed."
        exit 3
    fi
    result=$(( a % b ))
    echo "Result (a % b) = $result"
else
    echo "Error: Unknown operation '$op'. Use one of: + - * / %"
    exit 4
fi
# Classify the result using if/elif/else (three-way condition)
if   (( result > 0 )); then
    echo "The result is POSITIVE."
elif (( result == 0 )); then
    echo "The result is ZERO."
else
    echo "The result is NEGATIVE."
fi
exit 0
