package com.example.ahmad12345.Repository;



import com.example.ahmad12345.model.entity.WorkingSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Optional;


@Repository
public interface WorkingScheduleRepository
        extends JpaRepository<WorkingSchedule, Long> {
    List<WorkingSchedule> findByStaffId(Long staffId);

    List<WorkingSchedule> findByDayOfWeek(DayOfWeek dayOfWeek);

    List<WorkingSchedule> findByStaffIdAndDayOfWeek(Long staffId, DayOfWeek dayOfWeek);
}