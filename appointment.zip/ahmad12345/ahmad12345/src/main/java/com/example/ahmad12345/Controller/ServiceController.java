package com.example.ahmad12345.Controller;

import com.example.ahmad12345.model.dto.ServiceRequest;
import com.example.ahmad12345.model.dto.ServiceResponse;
import com.example.ahmad12345.service.ServiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/services")
@RequiredArgsConstructor
public class ServiceController {

    private final ServiceService serviceService;

    /**********************************************************************/

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<ServiceResponse> createService(
            @Valid @RequestBody ServiceRequest serviceRequest) {
        ServiceResponse createdService = serviceService.createService(serviceRequest);
        return new ResponseEntity<>(createdService, HttpStatus.CREATED);
    }

    /**الكل لازم يكون مسجل دخول***/
    @GetMapping
    public ResponseEntity<List<ServiceResponse>> getAllServices() {
        List<ServiceResponse> services = serviceService.getAllServices();
        return ResponseEntity.ok(services);
    }

    /****************************************************************************/

    @GetMapping("/{id}")
    public ResponseEntity<ServiceResponse> getServiceById(@PathVariable Long id) {
        ServiceResponse service = serviceService.getServiceById(id);
        return ResponseEntity.ok(service);
    }

    /*******************************************************************************/

    @GetMapping("/staff/{staffId}")
    public ResponseEntity<List<ServiceResponse>> getServicesByStaff(@PathVariable Long staffId) {
        List<ServiceResponse> services = serviceService.getServicesByStaffId(staffId);
        return ResponseEntity.ok(services);
    }

    /**********************************************************************/


    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<ServiceResponse> updateService(
            @PathVariable Long id,
            @Valid @RequestBody ServiceRequest serviceRequest) {
        ServiceResponse updatedService = serviceService.updateService(id, serviceRequest);
        return ResponseEntity.ok(updatedService);
    }

    /************************************************************************/

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteService(@PathVariable Long id) {
        serviceService.deleteService(id);
        return ResponseEntity.noContent().build();
    }

   /********************************************************************/
   
    @GetMapping("/search")
    public ResponseEntity<List<ServiceResponse>> searchServices(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String description) {

        List<ServiceResponse> services = serviceService.searchServices(name, description);
        return ResponseEntity.ok(services);
    }
}