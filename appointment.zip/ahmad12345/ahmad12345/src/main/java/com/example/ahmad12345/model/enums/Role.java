package com.example.ahmad12345.model.enums;

public enum Role {
    ADMIN,
    STAFF,
    CUSTOMER
}