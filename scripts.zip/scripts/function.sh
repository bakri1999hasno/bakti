#!/bin/bash
echo " enter the first name: "
read a
echo " enter the second name: "
read b

name()

{  
echo " your name is: $a $b"

}
name

