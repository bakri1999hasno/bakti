package com.example.ahmad12345.model.dto;


import lombok.Data;

@Data

public class AuthRequest {
    private String username;
    private String password;
    private String email;
    private String fullName;
    private String phone;
    private String role;
}
