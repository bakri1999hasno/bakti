package com.example.ahmad12345.service;

import com.example.ahmad12345.model.dto.AppointmentRequest;
import com.example.ahmad12345.model.dto.AppointmentResponse;
import com.example.ahmad12345.model.entity.Appointment;
import com.example.ahmad12345.model.entity.Servicee;
import com.example.ahmad12345.model.entity.User;
import com.example.ahmad12345.model.enums.AppointmentStatus;
import com.example.ahmad12345.Repository.AppointmentRepository;
import com.example.ahmad12345.Repository.ServiceRepository;
import com.example.ahmad12345.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final UserRepository userRepository;
    private final ServiceRepository serviceRepository;


    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

    /***********************************************************************/

    public AppointmentResponse createAppointment(AppointmentRequest request) {

        User customer = userRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new RuntimeException("customer not found with ID: " + request.getCustomerId()));

        Servicee service = serviceRepository.findById(request.getServiceId())
                .orElseThrow(() -> new RuntimeException("service not found with ID: " + request.getServiceId()));

        LocalTime startTime = request.getStartTime();
           LocalTime endTime = startTime.plusMinutes(service.getDuration());

        if (!isTimeSlotAvailable(request.getServiceId(), request.getAppointmentDate(), startTime)) {
            throw new RuntimeException("time slot is not available");
        }

        if (!isWithinWorkingHours(service.getStaff().getId(),
                request.getAppointmentDate().getDayOfWeek(),
                startTime, endTime)) {
            throw new RuntimeException("time slot is outside working hours");
        }

        Appointment appointment = new Appointment();
        appointment.setCustomer(customer);
        appointment.setService(service);
        appointment.setAppointmentDate(request.getAppointmentDate());
        appointment.setStartTime(startTime);
        appointment.setEndTime(endTime);
        appointment.setStatus(AppointmentStatus.PENDING);
        appointment.setNotes(request.getNotes());
        appointment.setCreatedAt(LocalDateTime.now());
        appointment.setUpdatedAt(LocalDateTime.now());

        Appointment savedAppointment = appointmentRepository.save(appointment);

        return convertToResponse(savedAppointment);
    }

    /**************************************************************************************/

    public List<AppointmentResponse> getAllAppointments() {
        return appointmentRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    /*************************************************************************************/


    public AppointmentResponse getAppointmentById(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("appointment not found with ID: " + id));
        return convertToResponse(appointment);
    }

    /*********************************************************************/


    public List<AppointmentResponse> getAppointmentsByCustomer(Long customerId) {

        if (!userRepository.existsById(customerId)) {
            throw new RuntimeException("vustomer not found with ID: " + customerId);
        }

        return appointmentRepository.findByCustomerId(customerId)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

  /*******************************************************************************/
    public List<AppointmentResponse> getAppointmentsByService(Long serviceId) {

        if (!serviceRepository.existsById(serviceId)) {
            throw new RuntimeException("service not found with ID: " + serviceId);
        }

        return appointmentRepository.findByServiceId(serviceId)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

   /********************************************************************/

    public List<AppointmentResponse> getAppointmentsByDate(LocalDate date) {
        return appointmentRepository.findByAppointmentDate(date)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

   /**************************************************************/

    public List<AppointmentResponse> getAppointmentsByStatus(String status) {
        AppointmentStatus appointmentStatus;
        try {
            appointmentStatus = AppointmentStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("invalid appointment status: " + status);
        }

        return appointmentRepository.findByStatus(appointmentStatus)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    /****************************************************************************************/


    public AppointmentResponse updateAppointmentStatus(Long id, String status) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("appointment not found with ID: " + id));

        AppointmentStatus newStatus;
        try {
            newStatus = AppointmentStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("invalid appointment status: " + status);
        }

        appointment.setStatus(newStatus);
        appointment.setUpdatedAt(LocalDateTime.now());

        Appointment updatedAppointment = appointmentRepository.save(appointment);

        return convertToResponse(updatedAppointment);
    }

    /*****************************************************************************/


    public void cancelAppointment(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("appointment not found with ID: " + id));

        if (appointment.getStatus() != AppointmentStatus.PENDING &&
                appointment.getStatus() != AppointmentStatus.APPROVED) {
            throw new RuntimeException("cannot cancel appointment with status: " + appointment.getStatus());
        }

        appointment.setStatus(AppointmentStatus.CANCELLED);
        appointment.setUpdatedAt(LocalDateTime.now());
        appointmentRepository.save(appointment);
    }


   /**************************************************************************************/


    public void deleteAppointment(Long id) {
        if (!appointmentRepository.existsById(id)) {
            throw new RuntimeException("appointment not found with ID: " + id);
        }
        appointmentRepository.deleteById(id);
    }


    /****************************************************************************************/


    public List<String> getAvailableTimeSlots(Long serviceId, LocalDate date) {
        Servicee service = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("service not found with ID: " + serviceId));

        List<LocalTime[]> workingHours = getWorkingHoursForDay(
                service.getStaff().getId(), date.getDayOfWeek());

        if (workingHours.isEmpty()) {
            return new ArrayList<>();
        }

        List<String> availableSlots = new ArrayList<>();
        int slotDuration = service.getDuration();

        for (LocalTime[] hours : workingHours) {
            LocalTime current = hours[0];
            while (current.plusMinutes(slotDuration).isBefore(hours[1].plusMinutes(1))) {
                if (isTimeSlotAvailable(serviceId, date, current)) {
                    availableSlots.add(current.format(TIME_FORMATTER));
                }
                current = current.plusMinutes(30);
            }
        }

        return availableSlots;
    }


    /*****************************************************************************************/


    public boolean isTimeSlotAvailable(Long serviceId, LocalDate date, LocalTime startTime) {
        Servicee service = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("service not found with ID: " + serviceId));

        LocalTime endTime = startTime.plusMinutes(service.getDuration());


        List<Appointment> conflictingAppointments = appointmentRepository
                .findConflictingAppointments(serviceId, date, startTime, endTime);

        return conflictingAppointments.isEmpty();
    }


    /************************************************************************************/


    private boolean isWithinWorkingHours(Long staffId, java.time.DayOfWeek dayOfWeek,
                                         LocalTime startTime, LocalTime endTime) {

        LocalTime workStart = LocalTime.of(9, 0);
                LocalTime workEnd = LocalTime.of(17, 0);

        if (dayOfWeek == java.time.DayOfWeek.SATURDAY ||
                dayOfWeek == java.time.DayOfWeek.FRIDAY) {
            return false;
        }

        return !startTime.isBefore(workStart) && !endTime.isAfter(workEnd);
    }

    /******************************************************************************/


    private List<LocalTime[]> getWorkingHoursForDay(Long staffId, java.time.DayOfWeek dayOfWeek) {
        List<LocalTime[]> workingHours = new ArrayList<>();

        switch (dayOfWeek) {
            case SUNDAY:
            case MONDAY:
            case TUESDAY:
            case WEDNESDAY:
            case THURSDAY:

                workingHours.add(new LocalTime[]{LocalTime.of(9, 0), LocalTime.of(17, 0)});
                break;
            case SATURDAY:
            case FRIDAY:
                break;
        }

        return workingHours;
    }

    /*****************************************************************************/

    private AppointmentResponse convertToResponse(Appointment appointment) {
        AppointmentResponse response = new AppointmentResponse();
        response.setId(appointment.getId());
        response.setCustomerId(appointment.getCustomer().getId());
        response.setCustomerName(appointment.getCustomer().getFullName());
        response.setServiceId(appointment.getService().getId());
        response.setServiceName(appointment.getService().getName());
        response.setAppointmentDate(appointment.getAppointmentDate());
        response.setStartTime(appointment.getStartTime());
        response.setEndTime(appointment.getEndTime());
        response.setDuration(appointment.getService().getDuration());
        response.setStatus(appointment.getStatus().name());
        response.setNotes(appointment.getNotes());
        response.setCreatedAt(appointment.getCreatedAt());
        response.setUpdatedAt(appointment.getUpdatedAt());
        response.setStaffId(appointment.getService().getStaff().getId());
        response.setStaffName(appointment.getService().getStaff().getFullName());
        response.setPrice(appointment.getService().getPrice());
        return response;
    }
}