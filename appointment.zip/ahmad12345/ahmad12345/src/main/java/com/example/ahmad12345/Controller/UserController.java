package com.example.ahmad12345.Controller;

import com.example.ahmad12345.Repository.UserRepository;
import com.example.ahmad12345.model.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
//@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }


    @PostMapping("/api/addusers")
    public User addUser(@RequestBody User user) {
        return userRepository.save(user);
    }


    @GetMapping("/api/getusers")
    public List<User> getAllUsers() {

        return userRepository.findAll();
    }
}