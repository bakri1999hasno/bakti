package com.example.ahmad12345.Repository;


import com.example.ahmad12345.model.entity.Servicee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ServiceRepository extends JpaRepository<Servicee, Long> {
    List<Servicee> findByStaffId(Long staffId);
    List<Servicee> findByNameContainingIgnoreCase(String name);
    List<Servicee> findByDescriptionContainingIgnoreCase(String description);
    List<Servicee> findByNameContainingIgnoreCaseAndDescriptionContainingIgnoreCase(
            String name, String description);
}