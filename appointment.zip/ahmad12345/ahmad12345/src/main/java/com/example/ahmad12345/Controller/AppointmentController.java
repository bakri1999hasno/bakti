package com.example.ahmad12345.Controller;

import com.example.ahmad12345.model.dto.AppointmentRequest;
import com.example.ahmad12345.model.dto.AppointmentResponse;
import com.example.ahmad12345.service.AppointmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    private final AppointmentService appointmentService;

    /*********************************************************************************/
    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<AppointmentResponse> createAppointment(
            @Valid @RequestBody AppointmentRequest request) {
        AppointmentResponse response = appointmentService.createAppointment(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    /*******************************************************************************/

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<AppointmentResponse>> getAllAppointments() {
        List<AppointmentResponse> appointments = appointmentService.getAllAppointments();
        return ResponseEntity.ok(appointments);
    }

    /*******************************************************************************/


    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or @appointmentSecurity.isAppointmentOwner(#id, authentication) or @appointmentSecurity.isServiceStaff(#id, authentication)")
    public ResponseEntity<AppointmentResponse> getAppointmentById(@PathVariable Long id) {
        AppointmentResponse appointment = appointmentService.getAppointmentById(id);
        return ResponseEntity.ok(appointment);
    }


    /********************************************************************************/


    @GetMapping("/customer/{customerId}")
    @PreAuthorize("hasRole('ADMIN') or (hasRole('CUSTOMER') and #customerId == authentication.principal.id)")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByCustomer(
            @PathVariable Long customerId) {
        List<AppointmentResponse> appointments = appointmentService.getAppointmentsByCustomer(customerId);
        return ResponseEntity.ok(appointments);
    }


   /**********************************************************************************************/


    @GetMapping("/service/{serviceId}")
    @PreAuthorize("hasRole('ADMIN') or @appointmentSecurity.isServiceStaffByServiceId(#serviceId, authentication)")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByService(
            @PathVariable Long serviceId) {
        List<AppointmentResponse> appointments = appointmentService.getAppointmentsByService(serviceId);
        return ResponseEntity.ok(appointments);
    }

    /**********************************************************************************/
    @GetMapping("/date")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByDate(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<AppointmentResponse> appointments = appointmentService.getAppointmentsByDate(date);
        return ResponseEntity.ok(appointments);
    }

    /**********************************************************************************/
    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByStatus(
            @PathVariable String status) {
        List<AppointmentResponse> appointments = appointmentService.getAppointmentsByStatus(status);
        return ResponseEntity.ok(appointments);
    }


    /************************************************************************/


    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    public ResponseEntity<AppointmentResponse> updateAppointmentStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        AppointmentResponse appointment = appointmentService.updateAppointmentStatus(id, status);
        return ResponseEntity.ok(appointment);
    }


    /***************************************************************************************/


    @DeleteMapping("/{id}/cancel")
    @PreAuthorize("hasRole('ADMIN') or (hasRole('CUSTOMER') and @appointmentSecurity.isAppointmentOwner(#id, authentication))")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Long id) {
        appointmentService.cancelAppointment(id);
        return ResponseEntity.noContent().build();
    }


    /******************************************************************************/


    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteAppointment(@PathVariable Long id) {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.noContent().build();
    }


    /****************************************************************************************/


    @GetMapping("/available")
    public ResponseEntity<List<String>> getAvailableSlots(
            @RequestParam Long serviceId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<String> availableSlots = appointmentService.getAvailableTimeSlots(serviceId, date);
        return ResponseEntity.ok(availableSlots);
    }


    /******************************************************************************************/


    @GetMapping("/check-availability")
    public ResponseEntity<Boolean> checkAvailability(
            @RequestParam Long serviceId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime) {
        boolean isAvailable = appointmentService.isTimeSlotAvailable(serviceId, date, startTime);
        return ResponseEntity.ok(isAvailable);
    }
}