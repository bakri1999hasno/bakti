package com.example.ahmad12345.model.dto;
import lombok.Data;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

@Data
public class ServiceRequest {
    @NotBlank
    private String name;

    private String description;

    @NotNull
    @Min(1)
    private Integer duration;

    @NotNull
    @DecimalMin("0.0")
    private BigDecimal price;

    @NotNull
    private Long staffId;
}