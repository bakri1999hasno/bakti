package com.example.ahmad12345;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ahmad12345ApplicationTests {

	@Test
	void contextLoads() {
	}

}
