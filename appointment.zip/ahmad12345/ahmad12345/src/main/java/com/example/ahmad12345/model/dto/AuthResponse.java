package com.example.ahmad12345.model.dto;


import lombok.AllArgsConstructor;
import lombok.Data;



@Data
@AllArgsConstructor

public class AuthResponse {
    private String token;
    private String message;
    private String username;
    private String role;
}