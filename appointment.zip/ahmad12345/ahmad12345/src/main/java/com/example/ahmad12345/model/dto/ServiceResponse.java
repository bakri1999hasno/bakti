package com.example.ahmad12345.model.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ServiceResponse {
    private Long id;
    private String name;
    private String description;
    private Integer duration;
    private BigDecimal price;
    private Long staffId;
    private String staffName;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}