package com.example.ahmad12345.service;

import com.example.ahmad12345.model.dto.ServiceRequest;
import com.example.ahmad12345.model.dto.ServiceResponse;
import com.example.ahmad12345.model.entity.Servicee;
import com.example.ahmad12345.model.entity.User;

import com.example.ahmad12345.Repository.ServiceRepository;

import com.example.ahmad12345.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class ServiceService {

    private final ServiceRepository serviceRepository;
    private final UserRepository userRepository;

    /*****************************************************************/


    public ServiceResponse createService(ServiceRequest request) {
        log.info("creating new service: {}", request.getName());

        User staff = userRepository.findById(request.getStaffId())
                .orElseThrow(() -> {
                    log.error("staff not found with ID: {}", request.getStaffId());
                    return new RuntimeException("staff not found with ID: " + request.getStaffId());
                });

        if (!staff.getRole().name().equals("STAFF") && !staff.getRole().name().equals("ADMIN")) {
            log.error("user with ID {} is not staff or admin", request.getStaffId());
            throw new RuntimeException("user is not staff or admin");
        }

         Servicee service = new Servicee();
           service.setName(request.getName());
        service.setDescription(request.getDescription());
              service.setDuration(request.getDuration());
           service.setPrice(request.getPrice());
              service.setStaff(staff);
           service.setCreatedAt(LocalDateTime.now());
              service.setUpdatedAt(LocalDateTime.now());

        Servicee savedService = serviceRepository.save(service);
        log.info("service created successfully with ID: {}", savedService.getId());

        return convertToResponse(savedService);
    }

   /*************************************************************/

    public List<ServiceResponse> getAllServices() {
        log.info("fetching all services");
        return serviceRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    /*************************************************************/

    public ServiceResponse getServiceById(Long id) {
        log.info("fetching service with ID: {}", id);

        Servicee service = serviceRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("service not found with ID: {}", id);
                    return new RuntimeException("service not found with ID: " + id);
                });

        return convertToResponse(service);
    }

   /********************************************************************/

    public List<ServiceResponse> getServicesByStaffId(Long staffId) {
        log.info("fetching services for staff ID: {}", staffId);


        if (!userRepository.existsById(staffId)) {
            log.error("staff not found with ID: {}", staffId);
            throw new RuntimeException("staff not found with ID: " + staffId);
        }

        return serviceRepository.findByStaffId(staffId)
                .stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

   /********************************************************************/

    public ServiceResponse updateService(Long id, ServiceRequest request) {
        log.info("updating service with ID: {}", id);

        Servicee service = serviceRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("service not found with ID: {}", id);
                    return new RuntimeException("service not found with ID: " + id);
                });


         service.setName(request.getName());
        service.setDescription(request.getDescription());
          service.setDuration(request.getDuration());
         service.setPrice(request.getPrice());
        service.setUpdatedAt(LocalDateTime.now());

        if (!service.getStaff().getId().equals(request.getStaffId())) {
            User newStaff = userRepository.findById(request.getStaffId())
                    .orElseThrow(() -> {
                        log.error("new staff not found with ID: {}", request.getStaffId());
                        return new RuntimeException("new staff not found with ID: " + request.getStaffId());
                    });


            if (!newStaff.getRole().name().equals("STAFF") && !newStaff.getRole().name().equals("ADMIN")) {
                log.error("new user with ID {} is not staff or admin", request.getStaffId());
                throw new RuntimeException("new user is not staff or admin");
            }

            service.setStaff(newStaff);
        }

        Servicee updatedService = serviceRepository.save(service);
        log.info("service with ID {} updated successfully", id);

        return convertToResponse(updatedService);
    }

    /***********************************************************************/

    public void deleteService(Long id) {
        log.info("deleting service with ID: {}", id);

        if (!serviceRepository.existsById(id)) {
            log.error("service not found with ID: {}", id);
            throw new RuntimeException("service not found with ID: " + id);
        }

        serviceRepository.deleteById(id);
        log.info("service with ID {} deleted successfully", id);
    }

    /***********************************************************************/


    public List<ServiceResponse> searchServices(String name, String description) {
        log.info("searching services with name: {}, description: {}", name, description);

        if (name != null && description != null) {
            return serviceRepository.findByNameContainingIgnoreCaseAndDescriptionContainingIgnoreCase(name, description)
                    .stream()
                    .map(this::convertToResponse)
                    .collect(Collectors.toList());
        } else if (name != null) {
            return serviceRepository.findByNameContainingIgnoreCase(name)
                    .stream()
                    .map(this::convertToResponse)
                    .collect(Collectors.toList());
        } else if (description != null) {
            return serviceRepository.findByDescriptionContainingIgnoreCase(description)
                    .stream()
                    .map(this::convertToResponse)
                    .collect(Collectors.toList());
        } else {
            return getAllServices();
        }
    }

    /**********************************************************************************/


    private ServiceResponse convertToResponse(Servicee service) {
        ServiceResponse response = new ServiceResponse();
        response.setId(service.getId());
        response.setName(service.getName());
        response.setDescription(service.getDescription());
        response.setDuration(service.getDuration());
        response.setPrice(service.getPrice());
        response.setStaffId(service.getStaff().getId());
        response.setStaffName(service.getStaff().getFullName());
        response.setCreatedAt(service.getCreatedAt());
        response.setUpdatedAt(service.getUpdatedAt());
        return response;
    }
}