package com.example.ahmad12345;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class Ahmad12345Application {

	public static void main(String[] args) {
		SpringApplication.run(Ahmad12345Application.class, args);
	}

}
